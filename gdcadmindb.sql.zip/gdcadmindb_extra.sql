
--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `jogcim`
--
ALTER TABLE `jogcim`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `kassza`
--
ALTER TABLE `kassza`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `jogcim`
--
ALTER TABLE `jogcim`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT a táblához `kassza`
--
ALTER TABLE `kassza`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
