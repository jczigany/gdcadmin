
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `jogcim`
--

CREATE TABLE `jogcim` (
  `id` int(11) NOT NULL,
  `jogcim` varchar(25) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `jogcim`
--

INSERT INTO `jogcim` (`id`, `jogcim`) VALUES
(1, 'Egyéb'),
(2, 'Tagdíj'),
(3, 'Ifjúsági tagdíj'),
(4, 'Bérlet'),
(5, 'Ifjúsági bérlet'),
(6, 'Napidíj'),
(7, 'Ifjúsági napidíj'),
(8, 'Adomány');
