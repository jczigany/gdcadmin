
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kassza`
--

CREATE TABLE `kassza` (
  `id` int(11) NOT NULL,
  `datum` date NOT NULL DEFAULT current_timestamp(),
  `befizeto` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `jogcim` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `ev` int(11) NOT NULL,
  `honap` int(11) NOT NULL,
  `osszeg` decimal(10,0) NOT NULL,
  `megjegyzes` varchar(100) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
