-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2020. Sze 29. 07:42
-- Kiszolgáló verziója: 10.4.11-MariaDB
-- PHP verzió: 7.3.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `gdcadmindb`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `jogcim`
--

CREATE TABLE `jogcim` (
  `id` int(11) NOT NULL,
  `jogcim` varchar(25) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `jogcim`
--

INSERT INTO `jogcim` (`id`, `jogcim`) VALUES
(1, 'Egyéb'),
(2, 'Tagdíj'),
(3, 'Ifjúsági tagdíj'),
(4, 'Bérlet'),
(5, 'Ifjúsági bérlet'),
(6, 'Napidíj'),
(7, 'Ifjúsági napidíj'),
(8, 'Adomány');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kassza`
--

CREATE TABLE `kassza` (
  `id` int(11) NOT NULL,
  `datum` date NOT NULL DEFAULT current_timestamp(),
  `befizeto` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `jogcim` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `ev` int(11) NOT NULL,
  `honap` int(11) NOT NULL,
  `osszeg` decimal(10,0) NOT NULL,
  `fizmod` varchar(10) COLLATE utf8_hungarian_ci NOT NULL DEFAULT 'Készpénz',
  `megjegyzes` varchar(100) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `kassza`
--

INSERT INTO `kassza` (`id`, `datum`, `befizeto`, `jogcim`, `ev`, `honap`, `osszeg`, `fizmod`, `megjegyzes`) VALUES
(2, '2020-09-28', 'Czigány János', 'Tagdíj', 2020, 11, '3000', 'Készpénz', 'Nincs megjegyzés'),
(4, '2020-09-28', 'Romhányi Renáta', 'Tagdíj', 2020, 10, '3000', 'Készpénz', ''),
(5, '2020-09-28', 'Czigány Dávid', 'Tagdíj', 2020, 10, '3000', 'Készpénz', 'Fehér kalap'),
(6, '2020-09-29', 'Dévai Gábor', 'Bérlet', 2020, 11, '5000', 'Készpénz', ''),
(7, '2020-09-29', 'Sáros Barnabás', 'Ifjúsági bérlet', 2020, 12, '3000', 'Készpénz', '');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `vezeteknev` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `utonev` varchar(20) COLLATE utf8_hungarian_ci NOT NULL,
  `szuletesi_ido` date NOT NULL,
  `irszam` varchar(4) COLLATE utf8_hungarian_ci NOT NULL,
  `helyseg` varchar(25) COLLATE utf8_hungarian_ci NOT NULL,
  `cim` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `telefon` varchar(15) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(35) COLLATE utf8_hungarian_ci NOT NULL,
  `tagsag_kezdete` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `members`
--

INSERT INTO `members` (`id`, `vezeteknev`, `utonev`, `szuletesi_ido`, `irszam`, `helyseg`, `cim`, `telefon`, `email`, `tagsag_kezdete`) VALUES
(11, 'Romhányi', 'Renáta', '2007-12-06', '2170', 'Aszód', 'Szőlő utca 16.', '+36-70-454-5791', 'reniromhanyi@gmail.com', '2020-06-29'),
(12, 'Czigány', 'János', '1968-05-20', '2170', 'Gödöllő', 'Szőlő utca 16.', '+36-70-367-9791', 'jczigany59@gmail.com', '2020-06-29'),
(13, 'Czigány', 'Dávid', '2009-05-05', '2170', 'Aszód', 'Szőlő utca 16.', '+36-30-335-8881', 'devertarate@gmail.com', '2020-09-01');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `jogcim`
--
ALTER TABLE `jogcim`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `kassza`
--
ALTER TABLE `kassza`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `jogcim`
--
ALTER TABLE `jogcim`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT a táblához `kassza`
--
ALTER TABLE `kassza`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT a táblához `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
