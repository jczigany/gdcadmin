
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `vezeteknev` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `utonev` varchar(20) COLLATE utf8_hungarian_ci NOT NULL,
  `szuletesi_ido` date NOT NULL,
  `irszam` varchar(4) COLLATE utf8_hungarian_ci NOT NULL,
  `helyseg` varchar(25) COLLATE utf8_hungarian_ci NOT NULL,
  `cim` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `telefon` varchar(15) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(35) COLLATE utf8_hungarian_ci NOT NULL,
  `tagsag_kezdete` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `members`
--

INSERT INTO `members` (`id`, `vezeteknev`, `utonev`, `szuletesi_ido`, `irszam`, `helyseg`, `cim`, `telefon`, `email`, `tagsag_kezdete`) VALUES
(11, 'Romhányi', 'Renáta', '1978-12-06', '2170', 'Aszód', 'Szőlő utca 16.', '+36-70-454-5791', 'reniromhanyi@gmail.com', '2020-06-29'),
(12, 'Czigány', 'János', '1968-05-20', '2170', 'Gödöllő', 'Szőlő utca 16.', '+36-70-367-9791', 'jczigany59@gmail.com', '2020-06-29');
